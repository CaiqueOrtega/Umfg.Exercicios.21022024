﻿namespace Umfg.Exercicios.CaiqueOrtega._2102024._6
{
    internal class Exercicio6
    {

        public static  int ContarVogais(string nomeUsuario)
        {
            int contador = 0;
            foreach (char caractere in nomeUsuario.ToLower())
            {
                if ("aeiou".Contains(caractere) && caractere != ' ')
                {
                    contador++;
                }
            }
            return contador;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("______________________");
            Console.WriteLine("  Contador de Vogais  ");
            Console.WriteLine("______________________");
            Console.WriteLine("Entre com seu nome:");
            String nomeUsuario = Console.ReadLine();


            Console.WriteLine("\n A quantidade de vogais no nome:" + nomeUsuario + " é " + ContarVogais(nomeUsuario));
            


        }
    }
}
