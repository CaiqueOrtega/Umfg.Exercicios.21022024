﻿namespace Umfg.Exercicios.CaiqueOrtega._21022024._7
{
    internal class Exercicio7
    {

        static int ContarConsoantes(string nomeUsuario)
        {
            int contador = 0;
            foreach (char caractere in nomeUsuario.ToLower())
            {
                if (!"aeiou ".Contains(caractere))
                {
                    contador++;
                }
            }
            return contador;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("__________________________");
            Console.WriteLine("   Contador de Consoantes ");
            Console.WriteLine("__________________________");
            Console.WriteLine("Entre com seu nome:");
            String nomeUsuario = Console.ReadLine();


            Console.WriteLine("\n A quantidade de Consoantes no nome:" + nomeUsuario + " é " + ContarConsoantes(nomeUsuario));



        }
    }
}
