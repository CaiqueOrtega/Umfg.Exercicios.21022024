﻿namespace Umfg.ExerciciosCaiqueOrtega._21022024._9
{
    internal struct Exercicio9
    {
        struct Livro
        {
            public string Titulo;
            public string Autor;
            public double Valor;

            public override string ToString()
            {
                return $"Título: {Titulo}\nAutor: {Autor}\nValor: {Valor:C}";
            }
        }


        static void Main(string[] args)
        {

            Livro livro;
            Console.WriteLine("_________________________________");
            Console.WriteLine("        Cadastro de Livro        ");
            Console.WriteLine("_________________________________");
            Console.WriteLine("Digite o título do livro:");
            livro.Titulo = Console.ReadLine();

            Console.WriteLine("Digite o autor do livro:");
            livro.Autor = Console.ReadLine();

            Console.WriteLine("Digite o valor do livro:");
            double.TryParse(Console.ReadLine(), out livro.Valor);

            Console.WriteLine("__________________________________");
            Console.WriteLine("\nInformações do livro cadastrado:");
            Console.WriteLine(livro);
        }
    }
 }

