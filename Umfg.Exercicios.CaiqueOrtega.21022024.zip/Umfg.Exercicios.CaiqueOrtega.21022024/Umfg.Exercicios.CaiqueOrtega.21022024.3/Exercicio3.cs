﻿namespace Umfg.Exercicios.CaiqueOrtega._21022024._3
{
    internal class Exercicio3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("_____________________________________________\n " +
                "Média de gasto de um automóvel \n" +
                "____________________________________________ \n");


            Console.WriteLine("Entre com distância total em KM Percorrida:");
            float.TryParse(Console.ReadLine(), out float distanciaPercorrida);


            Console.WriteLine("Entre com seu gasto de combustível em Lts.");
            float.TryParse(Console.ReadLine(), out float litrosCombustivel);

            float mediaPercorrida = distanciaPercorrida / litrosCombustivel;

            Console.WriteLine(mediaPercorrida + " Km por litro ");

        }
    }
}
