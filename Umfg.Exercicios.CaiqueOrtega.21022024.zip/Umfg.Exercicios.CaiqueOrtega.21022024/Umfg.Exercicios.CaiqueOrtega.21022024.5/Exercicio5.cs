﻿namespace Umfg.Exercicios.CaiqueOrtega._21022024._5
{
    internal class Exercicio5
    {

        public static float Soma(float numero1, float numero2)
        {

            return numero1 + numero2;


        }

        public static float Subtracao(float numero1, float numero2)
        {

            return numero1 - numero2;


        }


        public static float Multiplicacao(float numero1, float numero2)
        {

            return numero1 * numero2;


        }


        public static float Divisao(float numero1, float numero2)
        {

            return numero1 / numero2;


        }


        public static float RestoDivisao(float numero1, float numero2)
        {

            return numero1 % numero2;


        }

        public static (float, float) SolicitacaoDeDados(string tipoConta)
        {
            Console.WriteLine("_________________________");
            Console.WriteLine($"      "+tipoConta+"     ");
            Console.WriteLine("_________________________");

            Console.WriteLine("Entre com o primeiro número:");
            float.TryParse(Console.ReadLine(), out float num1);

            Console.WriteLine("Entre com o Segundo número:");
            float.TryParse(Console.ReadLine(), out float num2);

            return (num1, num2);
        }



        static void Main(string[] args)
        {
            float num1, num2;
            bool ativo = true;

            while (ativo)
            {
                Console.WriteLine("________________________________");
                Console.WriteLine("            Calculadora         ");
                Console.WriteLine("________________________________");
                Console.WriteLine("[]Atalho      Opções            ");
                Console.WriteLine("________________________________");
                Console.WriteLine("[1]           Soma              ");
                Console.WriteLine("[2]           Subtração         ");
                Console.WriteLine("[3]           Multiplicação     ");
                Console.WriteLine("[4]           Divisão           ");
                Console.WriteLine("[5]           Resto da Divisão"  );
                Console.WriteLine("________________________________");
                Console.WriteLine("[0] Sair do Sistema             ");
                Console.WriteLine("________________________________");
                int.TryParse(Console.ReadLine(), out int opcao);


                switch (opcao)
                {
                    case 0:
                        Console.WriteLine("Obrigado pela preferência!");
                        ativo = false;
                        break;

                        case 1:
                        (num1, num2) = SolicitacaoDeDados("Soma");
                        Console.WriteLine($"A soma de " + num1 + " e " + num2 + " é: " + Soma(num1, num2));
                        break;

                    case 2:
                        (num1, num2) = SolicitacaoDeDados("Subtração");

                        Console.WriteLine($"A subtração de " + num1 +" e " + num2 + " é: " + Subtracao(num1, num2));
                        break;

                    case 3:
                        (num1, num2) = SolicitacaoDeDados("Multiplicação");
                        Console.WriteLine("A Multiplicaçaõ de " + num1 + " e " + num2 +  " é: " + Multiplicacao(num1, num2));
                        
                        break;


                    case 4:
                        (num1, num2) = SolicitacaoDeDados("Divisão");
                        Console.WriteLine("A Divisão de " + num1 + " e " + num2 + " é: " + Divisao(num1, num2));
    
                        break;


                    case 5:
                        (num1, num2) = SolicitacaoDeDados("Resto da Divisão");
                        Console.WriteLine("O resto da divisão de "+ num1 + " e " + num2 + " é: "+ RestoDivisao(num1, num2));
                        break;


                    default:
                        Console.WriteLine("Entre com valores validos");
                        break;

                }
            }
           
        }
    }
}
