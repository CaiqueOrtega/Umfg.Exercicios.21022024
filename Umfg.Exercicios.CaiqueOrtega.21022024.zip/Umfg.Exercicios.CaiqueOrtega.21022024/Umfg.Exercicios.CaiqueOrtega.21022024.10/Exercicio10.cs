﻿namespace Umfg.Exercicios.CaiqueOrtega._21022024._10
{



    class Aluno
    {
        public string Nome { get; set; }
        public string RA { get; set; }
        public double NotaProva { get; set; }
        public double NotaTrabalho { get; set; }
        public int TotalFaltas { get; set; }

        public double CalcularMedia()
        {
            return (NotaProva * 0.7) + (NotaTrabalho * 0.3);
        }

        public double CalcularFrequencia()
        {
            double frequencia = ((25 - TotalFaltas) / 25.0) * 100;
            return frequencia;
        }

        public string Situacao()
        {
            double media = CalcularMedia();
            double frequencia = CalcularFrequencia();

            if (media >= 7 && frequencia >= 75)
            {
                return "APROVADO";
            }
            else
            {
                return "REPROVADO";
            }
        }
    }

    class Exercicio10
    {
        static List<Aluno> alunos = new List<Aluno>();

        static void Main(string[] args)
        {
            int opcao;

            do
            {
                Console.WriteLine("________________________________");
                Console.WriteLine("            Calculadora         ");
                Console.WriteLine("________________________________");
                Console.WriteLine("[]Atalho      Opções            ");
                Console.WriteLine("________________________________");
                Console.WriteLine("1 - Cadastro de Alunos          ");
                Console.WriteLine("2 - Cadastro de Notas           ");
                Console.WriteLine("3 - Cadastro Total de Faltas    ");
                Console.WriteLine("4 - Relação de Alunos           ");
                Console.WriteLine("________________________________");
                Console.WriteLine("[0] Sair do Sistema             ");
                Console.WriteLine("________________________________");
   

                opcao = int.Parse(Console.ReadLine());

                switch (opcao)
                {
                    case 1:
                        CadastroAluno();
                        break;
                    case 2:
                        CadastroNotas();
                        break;
                    case 3:
                        CadastroFaltas();
                        break;
                    case 4:
                        Relatorio();
                        break;
                    case 0:
                        Console.WriteLine("Programa encerrado.");
                        break;
                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }
            } while (opcao != 0);
        }

        static void CadastroAluno()
        {
            Aluno aluno = new Aluno();
            Console.WriteLine("________________________________");
            Console.WriteLine("        Cadastro de Aluno       ");
            Console.WriteLine("________________________________");
            Console.WriteLine("Digite o nome do aluno:");
            aluno.Nome = Console.ReadLine();

            Console.WriteLine("Digite o RA do aluno:");
            aluno.RA = Console.ReadLine();

            alunos.Add(aluno);
        }

        static void CadastroNotas()
        {
            Console.WriteLine("________________________________");
            Console.WriteLine("       Cadastro de Notas        ");
            Console.WriteLine("________________________________");
            Console.WriteLine("Digite o RA do aluno:");
            string ra = Console.ReadLine();

            Aluno aluno = alunos.Find(a => a.RA == ra);
            if (aluno == null)
            {
                Console.WriteLine("Aluno não encontrado.");
                return;
            }

            Console.WriteLine("Digite a nota da prova:");
            aluno.NotaProva = LerNota();

            Console.WriteLine("Digite a nota do trabalho:");
            aluno.NotaTrabalho = LerNota();
        }

        static void CadastroFaltas()
        {
            Console.WriteLine("________________________________");
            Console.WriteLine("       Cadastro de Faltas       ");
            Console.WriteLine("________________________________");
            Console.WriteLine("Digite o RA do aluno:");
            string ra = Console.ReadLine();

            Aluno aluno = alunos.Find(a => a.RA == ra);
            if (aluno == null)
            {
                Console.WriteLine("Aluno não encontrado.");
                return;
            }

            Console.WriteLine("Digite o total de faltas do aluno:");
            aluno.TotalFaltas = int.Parse(Console.ReadLine());
        }


        static void Relatorio()
        {
            Console.WriteLine("________________________________");
            Console.WriteLine("        Relação de Alunos       ");
            Console.WriteLine("________________________________");
            foreach (var aluno in alunos)
            {
                Console.WriteLine("Nome: " + aluno.Nome);
                Console.WriteLine("RA: " + aluno.RA);
                Console.WriteLine("Nota da Prova: " + aluno.NotaProva);
                Console.WriteLine("Nota do Trabalho: " + aluno.NotaTrabalho);
                Console.WriteLine($"Média: {aluno.CalcularMedia():F1}");
                Console.WriteLine("Total de Faltas:"  + aluno.TotalFaltas);
                Console.WriteLine($"Percentual de Frequência: {aluno.CalcularFrequencia():F1}%");
                Console.WriteLine($"Situação: " + aluno.Situacao());
                Console.WriteLine();
            }
        }

        static double LerNota()
        {
            double nota;
            do
            {
                Console.WriteLine("Nota deve estar entre 0 e 10:");
            } while (!double.TryParse(Console.ReadLine(), out nota) || nota < 0 || nota > 10);
            return nota;
        }
    }
}


