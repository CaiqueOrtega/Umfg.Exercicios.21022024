﻿namespace Umfg.CaiqueOrtega._21022024._8
{
    internal class Exercicio8
    {


        public static void ExibirFaixaEtaria(string nome, int idade)
        {
            string faixaEtaria;

            if (idade < 20)
            {
                faixaEtaria = "Jovem";
            }
            else if (idade < 60)
            {
                faixaEtaria = "Adulto";
            }
            else
            {
                faixaEtaria = "Idoso";
            }if(idade > 100)
            {
                faixaEtaria = "Decrépito";
            }

            Console.WriteLine($"\n{nome}, você possui {idade} anos e está na faixa etária de {faixaEtaria}.");
        }


        static void Main(string[] args)
        {
            Console.WriteLine("__________________________");
            Console.WriteLine(" Descubra sua Faixa Etária");
            Console.WriteLine("__________________________");

            Console.WriteLine("Entre com seu nome:");
            string nome = Console.ReadLine();

            Console.WriteLine("Entre com sua data de nascimento (no formato dd/mm/aaaa):");
            DateTime dataNascimento;
            while (!DateTime.TryParse(Console.ReadLine(), out dataNascimento))
            {
                Console.WriteLine("Formato de data inválido. Por favor, entre com uma data válida.");
            }


            int idade = DateTime.Today.Year - dataNascimento.Year;
            if (dataNascimento.Date > DateTime.Today.AddYears(-idade))
            {
                idade--;
            }

            ExibirFaixaEtaria(nome, idade);
        }
    }
}