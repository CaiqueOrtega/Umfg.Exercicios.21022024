﻿namespace Umfg.Exercicios.CaiqueOrtega._21022024._4
{
internal class Exercicio4
    {
        public static void SolicitarDataNascimento()
        {
            
                try
                {
                    Console.WriteLine("Entre com sua data de nascimento para saber sua idade:");
                    if (DateTime.TryParse(Console.ReadLine(), out DateTime dataNascimento))
                    {
                    CalcularIdade(dataNascimento);
                }
                    else
                    {
                        throw new FormatException();
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("\n Data inválida. Por favor, entre com uma data válida no formato dd/mm/aaaa. \n ");
                    SolicitarDataNascimento();
                }

        }

        public static void CalcularIdade(DateTime dataNascimento)
        {
            DateTime dataAtual = DateTime.Today;
            int idade = dataAtual.Year - dataNascimento.Year;
            if (dataNascimento > dataAtual.AddYears(-idade)) idade--;

            Console.WriteLine($"Sua idade é:" + idade + "anos.");
        }

        static void Main(string[] args)
        {
            SolicitarDataNascimento();
        }
    }
}