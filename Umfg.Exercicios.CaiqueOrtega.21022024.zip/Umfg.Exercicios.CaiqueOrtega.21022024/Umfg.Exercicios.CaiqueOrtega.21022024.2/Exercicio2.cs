﻿namespace Umfg.Exercicios.CaiqueOrtega._21022024._2
{
    internal class Exercicio2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Entre com o valor que deseja converter para BRL");

            decimal.TryParse(Console.ReadLine(), out decimal valorEmReal);

            decimal valorEmDolar = valorEmReal * 5.22m;

            Console.WriteLine("Valor em USD: " + valorEmDolar);
        }
    }
}
