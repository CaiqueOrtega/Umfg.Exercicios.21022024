﻿namespace Umfg.Exercicios.CaiqueOrtega._21022024
{
    internal class Exercicio1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Entre com o valor que deseja converter para USD");

            decimal.TryParse(Console.ReadLine(), out decimal valorEmDolar);

            decimal valorEmReal = valorEmDolar * 0.193259m;

            Console.WriteLine("Valor em BRL" + valorEmReal);
        }
    }
}
